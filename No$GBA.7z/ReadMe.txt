Hello to no$gba

Feedback,
if you have any constructive comments, suggestions, bug reports, please email
me (see webpage for email address). Please no threatening mails, I do already
have some, it's parts of amuzing and parts of boring. Please no questions
from beginners, I've no time to help you about whatever problems, that means,
I cannot, do not, did not, and will not help you.

--- DO NOT SEND ANY QUESTIONS ON HOW TO USE THE FREEWARE VERSION.
--- DO NOT SEND ANY QUESTIONS ON HOW TO USE OR PLAY GAMES.
--- DO NOT SEND ANY QUESTIONS ON HOW TO USE THE INTERNET.
--- DO NOT SEND ANY QUESTIONS ON HOW TO USE README.TXT.
--- DO NOT SEND ANY QUESTIONS ON HOW TO USE COMPUTERS.
--- DO NOT SEND ANY EMAILS WITH ATTACHMENTS.
--- ANYTHING I HAVE FORGOTTEN?
--- DON'T DO IT.

Homepage, updates, more info,
http://nocash.emubase.de/gba.htm

Debugger,
the no$gba debugger is a programming tool for professional developers.
To support hobby programmers, there's also a nice-price shareware debug
version available.
If you are a developer, please see no$gba homepage for more info.
If you aren't, please read the note below.

CAUTION:
The shareware & commecial versions include debugging features which are
useful for programmers ONLY, these versions are COMPLETELY USELESS for
gamers. That means, if you are a gamer, then you do NOT need to buy (or
steal) anything, you already GOT EVERYTHING you need FOR FREE.

----

Installation notes,
unzip the no$gba package into a new/blank folder (or into your existing
no$gba folder when installing an update) and start the no$gba.exe file.
For more info about additional files see built-in help. The program should
work (slowly) on any 80386SX (and up).

Uninstallation,
no$gba will eventually create some files and subdirectories in the no$gba
folder, aside from that it does not create or modify other files/registry
settings (except nocashio, see below). If no longer needed, just delete the
no$gba folder with all files/folders in it.

Nocashio,
a parallel port driver for windows NT/2K/XP, no$gba prompts you if you want
to install the driver (only when -if- accessing the parallel port under
NT/2K/XP). When -if- it is installed, you can uninstall it in no$gba
utility menu.

Martin
